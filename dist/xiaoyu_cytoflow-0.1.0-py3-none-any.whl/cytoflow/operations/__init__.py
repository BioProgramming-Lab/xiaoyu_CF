#!/usr/bin/env python3.8
# coding: latin-1

# (c) Massachusetts Institute of Technology 2015-2018
# (c) Brian Teague 2018-2022
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
cytoflow.operations
-------------------

This package contains all :mod:`cytoflow` operations -- classes
implementing `IOperation` whose `IOperation.apply` function takes an 
`Experiment` and returns an `Experiment`.  
"""

from .i_operation import IOperation
from .import_op import ImportOp
 
# gates
from .range import RangeOp
from .polygon import PolygonOp

# data-driven
from .density import DensityGateOp
 
# TASBE
from .autofluorescence import AutofluorescenceOp
from .bleedthrough_linear import BleedthroughLinearOp
